<form name="f-search" class="f-search" method="get" action="<?php echo home_url( '/' ); ?>">
<input type="text" name="s" class="q-search" placeholder="Search the Blog" />
<button type="submit" name="submit" class="btn-search"><i class="fa fa-search"></i></button>
</form>