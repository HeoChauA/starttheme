<?php 
$nimbus_text_logo = trim(nimbus_get_option('nimbus_text_logo'));
?>
<div class="navbar-brand-text"><a href="<?php echo home_url(); ?>"><?php echo $nimbus_text_logo; ?></a></div>

